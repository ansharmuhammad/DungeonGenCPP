var struct_b_s_p_tree_1_1node =
[
    [ "area", "struct_b_s_p_tree_1_1node.html#a4139f1bfa80d9d5b1c5c0608e392a876", null ],
    [ "left", "struct_b_s_p_tree_1_1node.html#a810d5cb9c2b9726bb1667c01ac8a839a", null ],
    [ "right", "struct_b_s_p_tree_1_1node.html#a15b889b75df92663facb7053d8ec35e0", null ]
];