var searchData=
[
  ['display',['display',['../classcell.html#a079f9f2751f6d3f174bd35d161b4f08b',1,'cell']]]
];
