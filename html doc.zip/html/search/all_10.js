var searchData=
[
  ['x',['x',['../classcell.html#a7c75a3656f94059da9e26a7ff2cdf75e',1,'cell::x()'],['../classrectangle.html#a03970481db05be5eb4e1b55eaba3b347',1,'rectangle::x()']]]
];
