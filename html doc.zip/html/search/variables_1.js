var searchData=
[
  ['color',['color',['../classcell.html#aca19b21960f06b4fbfd5549af2622710',1,'cell::color()'],['../classrectangle.html#a6124c9e734566c470a6daf30bfee87e9',1,'rectangle::color()']]]
];
