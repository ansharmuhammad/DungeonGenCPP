var indexSectionsWithContent =
{
  0: "abcdeghilmprsuvwxy~",
  1: "bcdglr",
  2: "bcdeglr",
  3: "abcdeglmprs~",
  4: "bcdhilmpvwxy",
  5: "dlru",
  6: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines",
  6: "pages"
};

var indexSectionLabels =
{
  0: "Semua",
  1: "Daftar Kelas",
  2: "File-file",
  3: "Fungsi",
  4: "Variabel",
  5: "Makro Definisi",
  6: "Halaman-halaman"
};

