var searchData=
[
  ['win32_5flean_5fand_5fmean',['WIN32_LEAN_AND_MEAN',['../stdafx_8h.html#ac7bef5d85e3dcd73eef56ad39ffc84a9',1,'stdafx.h']]]
];
