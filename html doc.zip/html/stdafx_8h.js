var stdafx_8h =
[
    [ "AFX_STDAFX_H__82B107C2_CA0A_11D3_AAA4_00A0CC601A2E__INCLUDED_", "stdafx_8h.html#a8b23960c004b9c34e32f1a915990b9fb", null ],
    [ "WIN32_LEAN_AND_MEAN", "stdafx_8h.html#ac7bef5d85e3dcd73eef56ad39ffc84a9", null ]
];