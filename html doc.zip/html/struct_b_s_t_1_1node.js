var struct_b_s_t_1_1node =
[
    [ "area", "struct_b_s_t_1_1node.html#a88dd9144a6cdf76d2e6f6a81743e804d", null ],
    [ "left", "struct_b_s_t_1_1node.html#aa6ee9a185d0191a598a548c11a26fb19", null ],
    [ "right", "struct_b_s_t_1_1node.html#a9a0cdc9122bfb97c5789ce1bdd6d40ad", null ]
];