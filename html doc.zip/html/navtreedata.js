/*
@ @licstart  The following is the entire license notice for the
JavaScript code in this file.

Copyright (C) 1997-2017 by Dimitri van Heesch

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

@licend  The above is the entire license notice
for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Dungeon Generator (BSP Tree & recursive bactracking) c++", "index.html", [
    [ "dungeon generator (BSP Tree & recursive backtracking)", "index.html", null ],
    [ "Daftar Kelas", "annotated.html", [
      [ "Daftar Kelas", "annotated.html", "annotated_dup" ],
      [ "Indeks Kelas", "classes.html", null ],
      [ "Daftar Anggota Kelas", "functions.html", [
        [ "Semua", "functions.html", null ],
        [ "Fungsi", "functions_func.html", null ],
        [ "Variabel", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "File-file", "files.html", [
      [ "Daftar File", "files.html", "files_dup" ],
      [ "Daftar Anggota File", "globals.html", [
        [ "Semua", "globals.html", null ],
        [ "Fungsi", "globals_func.html", null ],
        [ "Makro Definisi", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_b_s_p_tree_8cpp.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';